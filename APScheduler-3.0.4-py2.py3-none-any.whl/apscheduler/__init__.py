version_info = (3, 0, 4)
version = '3.0.4'
release = '3.0.4'

__version__ = release  # PEP 396
