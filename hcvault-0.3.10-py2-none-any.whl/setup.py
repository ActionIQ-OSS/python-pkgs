"""A setuptools based setup module.

See:
https://packaging.python.org/en/latest/distributing.html
https://github.com/pypa/sampleproject
"""
from setuptools import setup, find_packages
from codecs import open
from os import path

here = path.abspath(path.dirname(__file__))

setup(
    name='hcvault',  # Required
    version='0.3.10',  # Required
    description='A library with tools for creating a client for HashiCorp Vault',  # Required
    author='ActionIQ, JD Kemsley',  # Optional
    author_email='jdkemsley@actioniq.com',  # Optional
    classifiers=[  # Optional
        'Development Status :: 3 - Alpha',
        'Programming Language :: Python :: 2.7'
    ],
    packages=[''],
    # py_modules=['hcvault_exceptions', 'hcvault_client'],
    install_requires=['requests>=2.7.0', 'pyhcl'],  # Optional
    extras_require={
        'parser': ['pyhcl>=0.2.1,<0.3.0']
    },
    scripts=['hcvault']
)
