
__author__ = "Inada Naoki <songofacandy@gmail.com>"
version_info = (1,4,4,'final',0)
__version__ = "1.4.4"
