# -*- coding: utf-8 -*-
from luigi.cmdline import luigi_run

if __name__ == '__main__':
    luigi_run()
