import hcvault_exceptions
import hcvault_client
import json
import os
import errno
import getpass
import yaml
from contextlib import contextmanager

# Note: Stored context configs are cleartext, so they should only be used with short-term credentials.
# -- (NOT ROOT TOKENS) --
# Clients from root tokens can be created from an initialization data file with `root_client`

default_config_file = os.path.expanduser("~/.hcvault/context_config.yaml")
default_init_data_file = os.path.expanduser("~/.hcvault/init_data.json")
valid_auth_types = ["token", "userpass", "approle"]

environment_vars = {}
if os.environ.get("HCVAULT_URL"):
    environment_vars["url"] = os.environ.get("HCVAULT_URL")
if os.environ.get("HCVAULT_USER"):
    environment_vars["username"] = os.environ.get("HCVAULT_USER")
if os.environ.get("HCVAULT_PASS"):
    environment_vars["password"] = os.environ.get("HCVAULT_PASS")

# ================================================================================
#
# Managing the context config file
#
# ================================================================================


@contextmanager     # Yo dawg
def context_config(config_file):
    data = read_context_config(config_file)
    validate_context_config(data)
    yield data
    validate_context_config(data)
    write_context_config(data, config_file)


def read_context_config(config_file):
    # If there is no existing config file, just create a baseline config with nothing set.
    if not os.path.exists(config_file):
        return {
            "default_context": None,
            "contexts": {}
        }
    return read_yaml_file(config_file)


def write_context_config(data, config_file=default_config_file):
    write_yaml_file(config_file, data)


def validate_context_config(config):
    if "default_context" not in config or "contexts" not in config:
        raise hcvault_exceptions.ContextValidationError("Invalid context_config format. Must have 'default_context' "
                                                        "and 'contexts' keys")

    default_context = config["default_context"]
    if default_context and default_context not in config["contexts"]:
        print "Default context {} has no config values. Removing it as default.".format(default_context)
        config["default_context"] = None

    for context_name in config["contexts"]:
        validate_context(config["contexts"][context_name])


def validate_context(context_values):
    required_fields = ["url", "context_name", "auth_type"]
    for field in required_fields:
        if not context_values.get(field):
            raise hcvault_exceptions.ContextValidationError(context_values, "no {} specified".format(field))

    auth_type = context_values.get("auth_type")
    if auth_type not in valid_auth_types:
        raise hcvault_exceptions.ContextValidationError(context_values, "Invalid auth_type: {}"
                                                        .format(context_values.get("auth_type")))

    for a, b in {"userpass": "username", "approle": "role_id"}.items():
        if auth_type == a and not context_values.get(b):
            raise hcvault_exceptions.ContextValidationError(context_values,
                                                            "{} auth_type requires {} to be specified".format(a, b))


# ================================================================================
#
# Logical operations on contexts
#
# ================================================================================


def set_default_context(context_name, config_file=default_config_file):
    with context_config(config_file) as config:
        config["default_context"] = context_name
        print "Default context set to '{}'".format(context_name)


def get_context(context_name, config_file=default_config_file):
    with context_config(config_file) as config:
        if not config["contexts"].get(context_name):
            raise ValueError("No context found at {} with name {}".format(config_file, context_name))
        return config["contexts"][context_name]


def context_exists(context_name, config_file=default_config_file):
    with context_config(config_file) as config:
        return context_name in config["contexts"]


def get_context_names(config_file=default_config_file):
    with context_config(config_file) as config:
        return config["contexts"].keys()


def get_default_context(config_file=default_config_file):
    with context_config(config_file) as config:
        if not config["default_context"]:
            return None
    return config["contexts"][config["default_context"]]


def get_default_context_name(config_file=default_config_file):
    with context_config(config_file) as config:
        return config["default_context"]


def write_context(context_name, merge_values=False, config_file=default_config_file, **kwargs):
    with context_config(config_file) as config:
        context_values = {}
        if merge_values and config["contexts"].get(context_name):
            context_values.update(config["contexts"].get(context_name))
        context_values["context_name"] = context_name
        context_values.update(kwargs)
        config["contexts"][context_name] = context_values


def new_context(context_name, config_file=default_config_file, **kwargs):
    if context_exists(context_name, config_file):
        raise ValueError("Can't create new context {}: context already exists with that name".format(context_name))
    write_context(context_name, config_file=config_file, **kwargs)
    print "Context created : {}".format(context_name)


def update_context(context_name, config_file=default_config_file, **kwargs):
    write_context(context_name, config_file=config_file, merge_values=True, **kwargs)
    print "Context updated : {}".format(context_name)


def delete_context(context_name, config_file=default_config_file):
    with context_config(config_file) as config:
        config["contexts"].pop(context_name, None)
        print "Context deleted : {}".format(context_name)


def print_context(context_name=None, config_file=default_config_file, censor_token=True):
    with context_config(config_file) as config:
        if not context_name:
            context_name = config["default_context"]

        context_values = config["contexts"][context_name]
        if context_values.get("token") and censor_token:
            context_values["token"] = "CENSORED"
        print "'{}' context at {}:".format(context_values["context_name"], config_file)
        print context_values


def list_contexts(config_file=default_config_file):
    with context_config(config_file) as config:
        print "Contexts configured at {}:".format(config_file)
        for context in config["contexts"]:
            context_values = config["contexts"][context]
            print "{} ({} auth_type)".format(context_values["context_name"], context_values["auth_type"])


# ================================================================================
#
# Client generation and authentication
#
# ================================================================================


def default_client(config_file=default_config_file, prompt=True, do_auth=True, save_token=True, **kwargs):
    context_values = get_default_context(config_file)
    return client_from_context(context_name=context_values["context_name"], config_file=config_file, prompt=prompt,
                               do_auth=do_auth, save_token=save_token, **kwargs)


def client_from_context(context_name, config_file=default_config_file, prompt=True, do_auth=True, save_token=True,
                        **kwargs):
    # Context value heirarchy:
    # 1. command line (--extra_vars password=derp)
    # 2. env vars (export HCVAULT_PASS)
    # 3. prompt (password) or config file (everything else)
    context_values = get_context(context_name, config_file)
    original_token = context_values.get("token")    # pull og token before potential overwrite
    env_only_vars = set(environment_vars.keys()) - set(kwargs.keys())
    if env_only_vars:
        print("Getting the following context values from environment vars: {}"
              .format(env_only_vars))
    context_values.update(environment_vars)
    if kwargs:
        print("Getting the following context values from extra_vars: {}".format(kwargs.keys()))
    context_values.update(kwargs)
    validate_context(context_values)

    client = hcvault_client.HCVaultClient(
        url=context_values.get("url"),
        token=context_values.get("token"),
        cert=context_values.get("cert"),
        verify=context_values.get("verify") if context_values.get("verify") is not None else True,
        timeout=context_values.get("timeout") if context_values.get("timeout") is not None else 30,
        proxies=context_values.get("proxies"),
        allow_redirects=context_values.get("allow_redirects") if context_values.get("allow_redirects") is not None
        else True,
        session=context_values.get("session")
    )

    if do_auth:
        do_context_auth(context_values, client, prompt)

    if save_token and client.token and original_token != client.token:
        update_context(context_name, config_file, token=client.token)

    return client


def do_context_auth(context_values, client, prompt):
    if client.is_authenticated():
        return

    if not prompt:
        raise hcvault_exceptions.Unauthorized("Unable to authenticate context `{}` without user input. Set prompt=True "
                                              "when authenticating to allow for user input.")

    # Finish auth process with secure user input based on auth_type
    if context_values["auth_type"] == "token":
        do_token_auth(context_values, client)
    if context_values["auth_type"] == "userpass":
        do_userpass_auth(context_values, client)
    if context_values["auth_type"] == "approle":
        do_approle_auth(context_values, client)


def do_token_auth(context_values, client):
    context_name = context_values["context_name"]
    url = context_values["url"]
    token = getpass.getpass(prompt="Enter hcvault token for context '{}' at {} : ".format(context_name, url))
    client.token = token
    if not client.is_authenticated():
        raise hcvault_exceptions.Unauthorized("Invalid or expired token")


def do_userpass_auth(context_values, client):
    url = context_values["url"]
    username = context_values["username"]
    password = context_values.get("password")
    if not password:
        password = getpass.getpass(prompt="Enter hcvault password for user {} at {} : ".format(username, url))
    client.auth_userpass(username=username, password=password)
    if not client.is_authenticated():
        raise hcvault_exceptions.Unauthorized("Could not authenticate username '{}' at hcvault url {}."
                                              .format(username, url))


def do_approle_auth(context_values, client, secret_id=None):
    url = context_values["url"]
    role_id = context_values["role_id"]
    mount_point = context_values["mount_point"]
    secret_id = context_values.get("secret_id", secret_id)
    if not secret_id:
        raise hcvault_exceptions.Unauthorized(
            "Could not authenticate role_id '{}' at hcvault url {}. No secret_id."
            .format(role_id, url)
        )
    client.auth_approle(role_id=role_id, secret_id=secret_id, mount_point=mount_point)
    if not client.is_authenticated():
        raise hcvault_exceptions.Unauthorized(
            "Could not authenticate role_id '{}' at hcvault url {}."
            .format(role_id, url)
        )


def update_default_password(temp_token=None, config_file=default_config_file, save_token=True):
    context_values = get_default_context(config_file=config_file)
    if context_values["auth_type"] != "userpass":
        raise ValueError("Context '{}' is not a userpass context")

    username = context_values["username"]
    url = context_values["url"]
    client = default_client(config_file=config_file, do_auth=False)

    if temp_token:
        client.token = temp_token
        print("Updating password using temporary token")
    else:
        print("Updating password; first enter your current password")
        do_userpass_auth(context_values=context_values, client=client)

    password = getpass.getpass(prompt="Enter new hcvault password for user {} at {} : ".format(username, url))
    client.set_password(username=username, password=password)

    if save_token:
        update_context(context_name=context_values["context_name"], config_file=config_file, token=client.token)


def auth_default_context(config_file=default_config_file, **kwargs):
    context_values = get_default_context(config_file)
    if context_values:
        client_from_context(context_values["context_name"], config_file=config_file, do_auth=True, **kwargs)
    else:
        raise ValueError("No default context found, can't authenticate")
    print "Default context '{}' is authenticated".format(context_values["context_name"])


def default_is_authenticated(config_file=default_config_file):
    context = get_default_context(config_file)
    if not context:
        return False
    client = client_from_context(context["context_name"], config_file, do_auth=False)
    try:
        return client.is_authenticated()
    except Exception:       # We only care about whether we're authenticated here, not why
        return False


def print_default_auth_status(config_file=default_config_file):
    print "Default context name : {}".format(get_default_context_name(config_file))
    print "Default context authenticated : {}".format(default_is_authenticated(config_file))


def logout_context(context, config_file=default_config_file):
    if not context:
        print("No current context to log out from.")
        return False
    client = client_from_context(context["context_name"], config_file, do_auth=False)
    if client.is_authenticated():
        client.logout(revoke_token=True)
        print("Logged out with context {}".format(context["context_name"]))
        return True
    else:
        print("Already not logged into context {}".format(context["context_name"]))
        return True


def logout_context_by_name(context_name=None, config_file=default_config_file):
    if not context_name:
        context = get_default_context(config_file)
    else:
        context = get_context(context_name, config_file)
    return logout_context(context, config_file)


# ================================================================================
#
# Root token clients
#
# ================================================================================


# Init data files are raw recordings of data from hcvault at initialization time:
# {
#     "keys": ["", ""],
#     "keys_base64": ["", ""],
#     "root_token": "",
# }
def root_client(url, init_data_file=default_init_data_file):
    init_data = read_init_data(init_data_file)
    return hcvault_client.HCVaultClient(
        url=url,
        token=init_data.get("root_token")
    )


def read_init_data(init_data_file=default_init_data_file):
    if not os.path.exists(init_data_file):
        raise ValueError("No initialization data found at {}".format(init_data_file))
    with open(init_data_file, "r") as f:
        data = json.load(f)
        validate_init_data(data)
        return data


def validate_init_data(data):
    if not data:
        raise ValueError("Invalid initialization data: no values found")
    for required_value in ["root_token", "keys", "keys_base64"]:
        if required_value not in data:
            raise ValueError("Invalid initialization data: {} value required".format(required_value))


# ================================================================================
#
# I/O functions
#
# ================================================================================


# Create parent directories as with the 'mkdir -p' command
def mkdir_p(path):
    try:
        os.makedirs(path)
    except OSError as exc:
        if exc.errno == errno.EEXIST and os.path.isdir(path):
            pass
        else:
            raise


def read_yaml_file(filename):
    if not os.path.isfile(filename):
        return None
    with open(filename, "r") as f:
        return yaml.load(f)


def write_yaml_file(filename, data):
    mkdir_p(os.path.dirname(filename))
    with open(filename, "w") as f:
        yaml.dump(data, f)
