try:
    import hcl
    has_hcl_parser = True
except ImportError:
    has_hcl_parser = False
import requests

import hcvault_exceptions
import json
from urlparse import urljoin


def get_dev_client(token):
    return HCVaultClient(token=token)


class HCVaultClient(object):
    def __init__(self, url='http://localhost:8200', token=None,
                 cert=None, verify=True, timeout=30, proxies=None,
                 allow_redirects=True, session=None):

        if not session:
            session = requests.Session()

        self.allow_redirects = allow_redirects
        self.session = session
        self.token = token

        self.url = url
        self._kwargs = {
            'cert': cert,
            'verify': verify,
            'timeout': timeout,
            'proxies': proxies,
        }

    # ================================================================================
    #
    # Policies
    #
    # ================================================================================

    def list_policies(self):
        return self._get('/v1/sys/policy').json()['policies']

    def get_policy(self, name, parse=False):
        policy = self._get('/v1/sys/policy/{0}'.format(name)).json()['rules']
        if parse:
            if not has_hcl_parser:
                raise ImportError('pyhcl is required for policy parsing')

            policy = hcl.loads(policy)

        return policy

    def set_policy(self, name, rules):
        if isinstance(rules, dict):
            rules = json.dumps(rules)

        params = {
            'rules': rules,
        }

        self._put('/v1/sys/policy/{0}'.format(name), json=params)

    def delete_policy(self, name):
        self._delete('/v1/sys/policy/{0}'.format(name))

    # ================================================================================
    #
    # Tokens/ General Authentication
    #
    # ================================================================================

    def auth_from_token_file(self, filepath):
        with open(filepath, "r") as f:
            self.token = f.read().strip()

    def create_token(self, role=None, id=None, policies=None, meta=None,
                     no_parent=False, lease=None, display_name=None,
                     num_uses=None, no_default_policy=False,
                     ttl=None, orphan=False, wrap_ttl=None, renewable=None,
                     explicit_max_ttl=None):
        params = {
            'id': id,
            'policies': policies,
            'meta': meta,
            'no_parent': no_parent,
            'display_name': display_name,
            'num_uses': num_uses,
            'no_default_policy': no_default_policy,
            'renewable': renewable
        }

        if lease:
            params['lease'] = lease
        else:
            params['ttl'] = ttl
            params['explicit_max_ttl'] = explicit_max_ttl

        if explicit_max_ttl:
            params['explicit_max_ttl'] = explicit_max_ttl

        if orphan:
            return self._post('/v1/auth/token/create-orphan', json=params, wrap_ttl=wrap_ttl).json()
        elif role:
            return self._post('/v1/auth/token/create/{0}'.format(role), json=params, wrap_ttl=wrap_ttl).json()
        else:
            return self._post('/v1/auth/token/create', json=params, wrap_ttl=wrap_ttl).json()

    def lookup_token(self, token=None, accessor=False, wrap_ttl=None):
        if token:
            if accessor:
                path = '/v1/auth/token/lookup-accessor/{0}'.format(token)
                return self._post(path, wrap_ttl=wrap_ttl).json()
            else:
                return self._get('/v1/auth/token/lookup/{0}'.format(token)).json()
        else:
            return self._get('/v1/auth/token/lookup-self', wrap_ttl=wrap_ttl).json()

    def revoke_token(self, token, orphan=False, accessor=False):
        if accessor and orphan:
            msg = "revoke_token does not support 'orphan' and 'accessor' flags together"
            raise hcvault_exceptions.InvalidRequest(msg)
        elif accessor:
            self._post('/v1/auth/token/revoke-accessor/{0}'.format(token))
        elif orphan:
            self._post('/v1/auth/token/revoke-orphan/{0}'.format(token))
        else:
            self._post('/v1/auth/token/revoke/{0}'.format(token))

    def revoke_token_prefix(self, prefix):
        self._post('/v1/auth/token/revoke-prefix/{0}'.format(prefix))

    def revoke_self_token(self):
        self._put('/v1/auth/token/revoke-self')

    def renew_token(self, token=None, increment=None, wrap_ttl=None):
        params = {
            'increment': increment,
        }
        if token:
            path = '/v1/auth/token/renew/{0}'.format(token)
            return self._post(path, json=params, wrap_ttl=wrap_ttl).json()
        else:
            return self._post('/v1/auth/token/renew-self', json=params, wrap_ttl=wrap_ttl).json()

    def create_token_role(self, role,
                          allowed_policies=None, orphan=None, period=None,
                          renewable=None, path_suffix=None, explicit_max_ttl=None):
        params = {
            'allowed_policies': allowed_policies,
            'orphan': orphan,
            'period': period,
            'renewable': renewable,
            'path_suffix': path_suffix,
            'explicit_max_ttl': explicit_max_ttl
        }
        return self._post('/v1/auth/token/roles/{0}'.format(role), json=params)

    def token_role(self, role):
        return self.read('auth/token/roles/{0}'.format(role))

    def delete_token_role(self, role):
        return self.delete('auth/token/roles/{0}'.format(role))

    def list_token_roles(self):
        return self.list('auth/token/roles')

    def logout(self, revoke_token=False):
        """
        Clears the token used for authentication, optionally revoking it before doing so
        """
        if revoke_token:
            self.revoke_self_token()

        self.token = None

    def is_authenticated(self):
        """
        Helper method which returns the authentication status of the client
        """
        if not self.token:
            return False

        try:
            self.lookup_token()
            return True
        except hcvault_exceptions.Forbidden:
            return False
        except hcvault_exceptions.InvalidPath:
            return False
        except hcvault_exceptions.InvalidRequest:
            return False

    def auth(self, path, use_token=True, **kwargs):
        response = self._post(path, **kwargs).json()

        if use_token:
            self.token = response['auth']['client_token']

        return response

    def get_self_capabilities(self, path, **kwargs):
        params = {
            'path': path,
        }
        params.update(kwargs)
        return self._post('/v1/sys/capabilities-self', json=params).json()['capabilities']

    # ================================================================================
    #
    # General Secrets
    #
    # ================================================================================

    def renew_secret(self, lease_id, increment=None):
        params = {
            'increment': increment,
        }
        return self._post('/v1/sys/renew/{0}'.format(lease_id), json=params).json()

    def revoke_secret(self, lease_id):
        self._put('/v1/sys/revoke/{0}'.format(lease_id))

    def revoke_secret_prefix(self, path_prefix):
        self._put('/v1/sys/revoke-prefix/{0}'.format(path_prefix))

    # ================================================================================
    #
    # Key/Value Secrets
    #
    # ================================================================================

    # Key/Value Secrets belong to a specific backend -- 'kv'.  This backend is mounted by default at /secret
    def write_keyvalue(self, path, **kwargs):
        return self.write('/secret/{}'.format(path), **kwargs)

    def read_keyvalue(self, path):
        return self.read('/secret/{}'.format(path))['data']

    def delete_keyvalue(self, path):
        return self.delete('/secret/{}'.format(path))

    # ================================================================================
    #
    # Userpass
    #
    # ================================================================================

    def auth_userpass(self, username, password, mount_point='userpass', use_token=True, **kwargs):
        params = {
            'password': password,
        }

        params.update(kwargs)

        return self.auth('/v1/auth/{0}/login/{1}'.format(mount_point, username), json=params, use_token=use_token)

    def list_users(self, mount_point='userpass', **kwargs):
        return self.list("auth/{0}/users".format(mount_point))["data"]["keys"]

    def create_userpass(self, username, password, policies, mount_point='userpass', **kwargs):
        # Users can have more than 1 policy. It is easier for the user to pass in the
        # policies as a list so if they do, we need to convert to a comma delimited string.
        if isinstance(policies, (list, set, tuple)):
            policies = ','.join(policies)

        params = {
            'password': password,
            'policies': policies
        }
        params.update(kwargs)

        return self._post('/v1/auth/{0}/users/{1}'.format(mount_point, username), json=params)

    def get_userpass(self, username, mount_point='userpass'):
        return self._get('/v1/auth/{0}/users/{1}'.format(mount_point, username))

    def userpass_exists(self, username, mount_point='userpass'):
        try:
            self.get_userpass(username, mount_point)
            return True
        except hcvault_exceptions.InvalidPath:
            return False

    def delete_userpass(self, username, mount_point='userpass'):
        return self._delete('/v1/auth/{0}/users/{1}'.format(mount_point, username))

    def set_userpass_policies(self, username, policies, mount_point='userpass', **kwargs):
        if isinstance(policies, (list, set, tuple)):
            policies = ','.join(policies)

        params = {
            'policies': policies
        }
        params.update(kwargs)

        return self._post('/v1/auth/{0}/users/{1}'.format(mount_point, username), json=params)

    def get_userpass_policies(self, username, mount_point='userpass', **kwargs):
        return self._get('/v1/auth/{0}/users/{1}'.format(mount_point, username)).json()['data']['policies']

    def set_password(self, username, password, mount_point='userpass', **kwargs):
        params = {
            'password': password
        }
        params.update(kwargs)
        self._put('/v1/auth/{0}/users/{1}/password'.format(mount_point, username), json=params)

    # ================================================================================
    #
    # Ec2
    #
    # ================================================================================

    def auth_ec2(self, pkcs7, nonce=None, role=None, use_token=True):
        params = {'pkcs7': pkcs7}
        if nonce:
            params['nonce'] = nonce
        if role:
            params['role'] = role

        return self.auth('/v1/auth/aws-ec2/login', json=params, use_token=use_token)

    def create_vault_ec2_client_configuration(self, access_key, secret_key, endpoint=None):
        params = {
            'access_key': access_key,
            'secret_key': secret_key
        }
        if endpoint is not None:
            params['endpoint'] = endpoint

        return self._post('/v1/auth/aws-ec2/config/client', json=params)

    def get_vault_ec2_client_configuration(self):
        return self._get('/v1/auth/aws-ec2/config/client').json()

    def delete_vault_ec2_client_configuration(self):
        return self._delete('/v1/auth/aws-ec2/config/client')

    def create_vault_ec2_certificate_configuration(self, cert_name, aws_public_cert):
        params = {
            'cert_name': cert_name,
            'aws_public_cert': aws_public_cert
        }
        return self._post('/v1/auth/aws-ec2/config/certificate/{0}'.format(cert_name), json=params)

    def get_vault_ec2_certificate_configuration(self, cert_name):
        return self._get('/v1/auth/aws-ec2/config/certificate/{0}'.format(cert_name)).json()

    def list_vault_ec2_certificate_configurations(self):
        params = {'list': True}
        return self._get('/v1/auth/aws-ec2/config/certificates', params=params).json()

    def create_ec2_role(self, role, bound_ami_id, role_tag=None, max_ttl=None, policies=None,
                        allow_instance_migration=False, disallow_reauthentication=False, **kwargs):
        params = {
            'role': role,
            'bound_ami_id': bound_ami_id,
            'disallow_reauthentication': disallow_reauthentication,
            'allow_instance_migration': allow_instance_migration
        }
        if role_tag is not None:
            params['role_tag'] = role_tag
        if max_ttl is not None:
            params['max_ttl'] = max_ttl
        if policies is not None:
            params['policies'] = policies
        params.update(**kwargs)
        return self._post('/v1/auth/aws-ec2/role/{0}'.format(role), json=params)

    def get_ec2_role(self, role):
        return self._get('/v1/auth/aws-ec2/role/{0}'.format(role)).json()

    def delete_ec2_role(self, role):
        return self._delete('/v1/auth/aws-ec2/role/{0}'.format(role))

    def list_ec2_roles(self):
        return self._get('/v1/auth/aws-ec2/roles', params={'list': True}).json()

    def create_ec2_role_tag(self, role, policies=None, max_ttl=None, instance_id=None,
                            disallow_reauthentication=False, allow_instance_migration=False):
        params = {
            'role': role,
            'disallow_reauthentication': disallow_reauthentication,
            'allow_instance_migration': allow_instance_migration
        }
        if max_ttl is not None:
            params['max_ttl'] = max_ttl
        if policies is not None:
            params['policies'] = policies
        if instance_id is not None:
            params['instance_id'] = instance_id
        return self._post('/v1/auth/aws-ec2/role/{0}/tag'.format(role), json=params).json()

    # ================================================================================
    #
    # App ID (deprecated)
    #
    # ================================================================================

    def auth_app_id(self, app_id, user_id, mount_point='app-id', use_token=True):
        params = {
            'app_id': app_id,
            'user_id': user_id,
        }

        return self.auth('/v1/auth/{0}/login'.format(mount_point), json=params, use_token=use_token)

    def create_app_id(self, app_id, policies, display_name=None, mount_point='app-id', **kwargs):
        # app-id can have more than 1 policy. It is easier for the user to pass in the
        # policies as a list so if they do, we need to convert to a comma delimited string.
        if isinstance(policies, (list, set, tuple)):
            policies = ','.join(policies)

        params = {
            'value': policies
        }

        # Only use the display_name if it has a value. Made it a named param for user
        # convienence instead of leaving it as part of the kwargs
        if display_name:
            params['display_name'] = display_name

        params.update(kwargs)

        return self._post('/v1/auth/{0}/map/app-id/{1}'.format(mount_point, app_id), json=params)

    def get_app_id(self, app_id, mount_point='app-id', wrap_ttl=None):
        path = '/v1/auth/{0}/map/app-id/{1}'.format(mount_point, app_id)
        return self._get(path, wrap_ttl=wrap_ttl).json()

    def delete_app_id(self, app_id, mount_point='app-id'):
        return self._delete('/v1/auth/{0}/map/app-id/{1}'.format(mount_point, app_id))

    def create_user_id(self, user_id, app_id, cidr_block=None, mount_point='app-id', **kwargs):
        # user-id can be associated to more than 1 app-id (aka policy). It is easier for the user to
        # pass in the policies as a list so if they do, we need to convert to a comma delimited string.
        if isinstance(app_id, (list, set, tuple)):
            app_id = ','.join(app_id)

        params = {
            'value': app_id
        }

        # Only use the cidr_block if it has a value. Made it a named param for user
        # convienence instead of leaving it as part of the kwargs
        if cidr_block:
            params['cidr_block'] = cidr_block

        params.update(kwargs)

        return self._post('/v1/auth/{0}/map/user-id/{1}'.format(mount_point, user_id), json=params)

    def get_user_id(self, user_id, mount_point='app-id', wrap_ttl=None):
        path = '/v1/auth/{0}/map/user-id/{1}'.format(mount_point, user_id)
        return self._get(path, wrap_ttl=wrap_ttl).json()

    def delete_user_id(self, user_id, mount_point='app-id'):
        return self._delete('/v1/auth/{0}/map/user-id/{1}'.format(mount_point, user_id))

    # ================================================================================
    #
    # AppRole
    #
    # ================================================================================

    def create_role(self, role_name, mount_point="approle", **kwargs):
        self._post('/v1/auth/{0}/role/{1}'.format(mount_point, role_name), json=kwargs)

    def list_roles(self, mount_point="approle"):
        return self._get('/v1/auth/{0}/role?list=true'.format(mount_point)).json()

    def get_role(self, role_name, mount_point="approle"):
        return self._get('/v1/auth/{0}/role/{1}'.format(mount_point, role_name)).json()

    def get_role_id(self, role_name, mount_point="approle"):
        return self._get('/v1/auth/{0}/role/{1}/role-id'.format(mount_point, role_name)).json()

    def set_role_id(self, role_name, role_id, mount_point="approle"):
        params = {
            'role_id': role_id
        }
        self._post('/v1/auth/{0}/role/{1}/role-id'.format(mount_point, role_name), json=params)

    def create_role_secret_id(self, role_name, mount_point="approle", meta=None):
        params = {}
        if meta is not None:
            params['metadata'] = json.dumps(meta)

        return self._post('/v1/auth/{0}/role/{1}/secret-id'.format(mount_point, role_name), json=params).json()

    def create_role_custom_secret_id(self, role_name, secret_id, mount_point="approle", meta=None):
        params = {
            'secret_id': secret_id
        }
        if meta is not None:
            params['meta'] = meta
        return self._post('/v1/auth/{0}/role/{1}/custom-secret-id'.format(mount_point, role_name), json=params).json()

    def get_role_secret_ids(self, role_name, mount_point="approle"):
        return self._get('/v1/auth/{0}/role/{1}/secret-id?list=true'.format(mount_point, role_name)).json()

    def get_role_secret_id_info(self, role_name, secret_id, mount_point="approle"):
        params = {
            'secret_id': secret_id
        }
        return self._post('/v1/auth/{0}/role/{1}/secret-id/lookup'.format(mount_point, role_name), json=params).json()

    def get_role_secret_id_accessor(self, role_name, secret_id_accessor, mount_point="approle"):
        params = {
            "secret_id_accessor": secret_id_accessor
        }
        response = self._post('/v1/auth/{0}/role/{1}/secret-id-accessor/lookup'.format(mount_point, role_name), json=params)
        results = response.json() if response.status_code == 200 else None
        return results

    def delete_role(self, role_name, mount_point="approle"):
        return self._delete("/v1/auth/{0}/role/{1}".format(mount_point, role_name))

    def delete_role_secret_id(self, role_name, secret_id, mount_point="approle"):
        params = {
            'secret_id': secret_id
        }
        # TODO: remove `.lower()` with hcvault version 0.10.2 (https://github.com/ActionIQ/aiq/issues/12997)
        modified_role_name = role_name.lower()
        self._post('/v1/auth/{0}/role/{1}/secret-id/destroy'.format(mount_point, modified_role_name), json=params)

    def delete_role_secret_id_by_accessor(self, role_name, secret_id_accessor, mount_point="approle"):
        params = {
            'secret_id_accessor': secret_id_accessor
        }
        # TODO: remove `.lower()` with hcvault version 0.10.2 (https://github.com/ActionIQ/aiq/issues/12997)
        modified_role_name = role_name.lower()
        self._post('/v1/auth/{0}/role/{1}/secret-id-accessor/destroy'.format(mount_point, modified_role_name))

    def auth_approle(self, role_id, secret_id=None, mount_point='approle', use_token=True):
        params = {
            'role_id': role_id
        }
        if secret_id is not None:
            params['secret_id'] = secret_id

        return self.auth('/v1/auth/{0}/login'.format(mount_point), json=params, use_token=use_token)

    # ================================================================================
    #
    # Other auth backends
    #
    # ================================================================================

    def auth_tls(self, mount_point='cert', use_token=True):
        return self.auth('/v1/auth/{0}/login'.format(mount_point), use_token=use_token)

    def auth_ldap(self, username, password, mount_point='ldap', use_token=True, **kwargs):
        params = {
            'password': password,
        }

        params.update(kwargs)

        return self.auth('/v1/auth/{0}/login/{1}'.format(mount_point, username), json=params, use_token=use_token)

    def auth_github(self, token, mount_point='github', use_token=True):
        params = {
            'token': token,
        }

        return self.auth('/v1/auth/{0}/login'.format(mount_point), json=params, use_token=use_token)

    # ================================================================================
    #
    # Vault Basic Operations
    #
    # ================================================================================

    def read(self, path, wrap_ttl=None):
        return self._get('/v1/{0}'.format(path), wrap_ttl=wrap_ttl).json()

    def read_data(self, path, *args):
        secret = self.read(path)['data']
        for key in args:
            secret = secret[key]
        return secret

    def list(self, path):
        payload = {
            'list': True
        }
        return self._get('/v1/{0}'.format(path), params=payload).json()

    def write(self, path, wrap_ttl=None, **kwargs):
        response = self._put('/v1/{0}'.format(path), json=kwargs, wrap_ttl=wrap_ttl)

        if response.status_code == 200:
            return response.json()

    def delete(self, path):
        self._delete('/v1/{0}'.format(path))

    def unwrap(self, token):
        """
        POST /sys/wrapping/unwrap
        X-Vault-Token: <token>
        """
        _token = self.token
        try:
            self.token = token
            return self._post('/v1/sys/wrapping/unwrap').json()
        finally:
            self.token = _token

    # ================================================================================
    #
    # Raw HTTP
    #
    # ================================================================================

    def close(self):
        """
        Close the underlying Requests session
        """
        self.session.close()

    def _get(self, path, **kwargs):
        return self.__request('get', path, **kwargs)

    def _list(self, path, **kwargs):
        return self.__request('list', path, **kwargs)

    def _post(self, path, **kwargs):
        return self.__request('post', path, **kwargs)

    def _put(self, path, **kwargs):
        return self.__request('put', path, **kwargs)

    def _delete(self, path, **kwargs):
        return self.__request('delete', path, **kwargs)

    def __request(self, method, path, headers=None, **kwargs):
        url = urljoin(self.url, path)

        if not headers:
            headers = {}

        if self.token:
            headers['X-Vault-Token'] = self.token

        wrap_ttl = kwargs.pop('wrap_ttl', None)
        if wrap_ttl:
            headers['X-Vault-Wrap-TTL'] = str(wrap_ttl)

        _kwargs = self._kwargs.copy()
        _kwargs.update(kwargs)

        response = self.session.request(method, url, headers=headers,
                                        allow_redirects=False, **_kwargs)

        # NOTE(ianunruh): workaround for https://github.com/ianunruh/hvac/issues/51
        while response.is_redirect and self.allow_redirects:
            url = urljoin(self.url, response.headers['Location'])
            response = self.session.request(method, url, headers=headers,
                                            allow_redirects=False, **_kwargs)

        if response.status_code >= 400:
            message = response.text
            if response.headers.get('Content-Type') == 'application/json':
                errors = response.json().get('errors')
                if errors:
                    message = ", ".join(errors)
            self.__raise_error(path=path, message=message, status_code=response.status_code)

        return response

    def __raise_error(self, path, message="", status_code=None):
        message = "At path {} : {}".format(path, message)
        if status_code:
            message = "Status Code {}: {}".format(status_code, message)

        if status_code == 400:
            raise hcvault_exceptions.InvalidRequest(message)
        elif status_code == 401:
            raise hcvault_exceptions.Unauthorized(message)
        elif status_code == 403:
            raise hcvault_exceptions.Forbidden(message)
        elif status_code == 404:
            raise hcvault_exceptions.InvalidPath(message)
        elif status_code == 429:
            raise hcvault_exceptions.RateLimitExceeded(message)
        elif status_code == 500:
            raise hcvault_exceptions.InternalServerError(message)
        elif status_code == 501:
            raise hcvault_exceptions.VaultNotInitialized(message)
        elif status_code == 503:
            raise hcvault_exceptions.VaultSealed(message)
        else:
            raise hcvault_exceptions.UnexpectedError(message)

    # ================================================================================
    #
    # Vault State Management
    #
    # ================================================================================

    # This will throw the appropriate exception for each case of an invalid vault
    # An uninitialized vault returns a 501 from this endpoint, a sealed vault returns a 503, etc
    # A perfectly healthy vault will result in no exceptions
    def validate_healthy_vault(self):
        self._get('/v1/sys/health')
        return True

    def is_healthy_vault(self):
        try:
            self.validate_healthy_vault()
        except hcvault_exceptions.VaultError:
            return False
        return True

    def is_initialized(self):
        return self._get('/v1/sys/init').json()['initialized']

    def initialize(self, secret_shares=5, secret_threshold=3, pgp_keys=None):
        params = {
            'secret_shares': secret_shares,
            'secret_threshold': secret_threshold,
        }

        if pgp_keys:
            if len(pgp_keys) != secret_shares:
                raise ValueError('Length of pgp_keys must equal secret shares')

            params['pgp_keys'] = pgp_keys

        return self._put('/v1/sys/init', json=params).json()

    @property
    def seal_status(self):
        return self._get('/v1/sys/seal-status').json()

    def is_sealed(self):
        return self.seal_status['sealed']

    def seal(self):
        self._put('/v1/sys/seal')

    def unseal_reset(self):
        params = {
            'reset': True,
        }
        return self._put('/v1/sys/unseal', json=params).json()

    def unseal(self, key):
        params = {
            'key': key,
        }

        return self._put('/v1/sys/unseal', json=params).json()

    def unseal_multi(self, keys):
        result = None

        for key in keys:
            result = self.unseal(key)
            if not result['sealed']:
                break

        return result

    @property
    def key_status(self):
        return self._get('/v1/sys/key-status').json()

    def rotate(self):
        self._put('/v1/sys/rotate')

    @property
    def rekey_status(self):
        return self._get('/v1/sys/rekey/init').json()

    def start_rekey(self, secret_shares=5, secret_threshold=3, pgp_keys=None,
                    backup=False):
        params = {
            'secret_shares': secret_shares,
            'secret_threshold': secret_threshold,
        }

        if pgp_keys:
            if len(pgp_keys) != secret_shares:
                raise ValueError('Length of pgp_keys must equal secret shares')

            params['pgp_keys'] = pgp_keys
            params['backup'] = backup

        resp = self._put('/v1/sys/rekey/init', json=params)
        if resp.text:
            return resp.json()

    def cancel_rekey(self):
        self._delete('/v1/sys/rekey/init')

    def rekey(self, key, nonce=None):
        params = {
            'key': key,
        }

        if nonce:
            params['nonce'] = nonce

        return self._put('/v1/sys/rekey/update', json=params).json()

    def rekey_multi(self, keys, nonce=None):
        result = None

        for key in keys:
            result = self.rekey(key, nonce=nonce)
            if 'complete' in result and result['complete']:
                break

        return result

    def get_backed_up_keys(self):
        return self._get('/v1/sys/rekey/backup').json()

    @property
    def ha_status(self):
        return self._get('/v1/sys/leader').json()

    # ================================================================================
    #
    # Vault Backend Management
    #
    # ================================================================================

    def list_secret_backends(self):
        return self._get('/v1/sys/mounts').json()

    def read_secret_backend_config(self, mount_point):
        return self._get('/v1/sys/mounts/{}/tune'.format(mount_point)).json()

    def secret_backend_mount_exists(self, mount_point):
        return "{}/".format(mount_point) in self.list_secret_backends()

    def enable_secret_backend(self, backend_type, description=None, mount_point=None, config=None):
        if not mount_point:
            mount_point = backend_type
        params = {
            'type': backend_type,
            'description': description,
            'config': config,
        }

        self._post('/v1/sys/mounts/{0}'.format(mount_point), json=params)

    def tune_secret_backend(self, mount_point, config):
        self._post('/v1/sys/mounts/{0}/tune'.format(mount_point), json=config)

    def disable_secret_backend(self, mount_point):
        self._delete('/v1/sys/mounts/{0}'.format(mount_point))

    def remount_secret_backend(self, from_mount_point, to_mount_point):
        params = {
            'from': from_mount_point,
            'to': to_mount_point,
        }

        self._post('/v1/sys/remount', json=params)

    def list_auth_backends(self):
        return self._get('/v1/sys/auth').json()

    def read_auth_backend_config(self, mount_point):
        return self._get('/v1/sys/auth/{}/tune'.format(mount_point)).json()

    def auth_backend_mount_exists(self, mount_point):
        return "{}/".format(mount_point) in self.list_auth_backends()

    def enable_auth_backend(self, backend_type, description=None, mount_point=None, config=None):
        if not mount_point:
            mount_point = backend_type
        params = {
            'type': backend_type,
            'description': description,
            'config': config
        }

        self._post('/v1/sys/auth/{0}'.format(mount_point), json=params)

    def tune_auth_backend(self, mount_point, config):
        self._post('/v1/sys/auth/{0}/tune'.format(mount_point), json=config)

    def disable_auth_backend(self, mount_point):
        self._delete('/v1/sys/auth/{0}'.format(mount_point))

    def list_audit_backends(self):
        return self._get('/v1/sys/audit').json()

    def audit_backend_mount_exists(self, mount_point):
        return "{}/".format(mount_point) in self.list_audit_backends()

    def enable_audit_backend(self, backend_type, description=None, options=None, name=None):
        if not name:
            name = backend_type

        params = {
            'type': backend_type,
            'description': description,
            'options': options,
        }

        self._post('/v1/sys/audit/{0}'.format(name), json=params)

    def disable_audit_backend(self, name):
        self._delete('/v1/sys/audit/{0}'.format(name))

    def audit_hash(self, name, input):
        params = {
            'input': input,
        }
        return self._post('/v1/sys/audit-hash/{0}'.format(name), json=params).json()
