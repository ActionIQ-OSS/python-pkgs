import hcvault_client


# Putting this here makes it less verbose to create a client from the wheel library
def client(url='http://localhost:8200', token=None, cert=None, verify=True, timeout=30, proxies=None,
           allow_redirects=True, session=None):
    return hcvault_client.HCVaultClient(url=url, token=token, cert=cert, verify=verify, timeout=timeout,
                                        proxies=proxies, allow_redirects=allow_redirects, session=session)