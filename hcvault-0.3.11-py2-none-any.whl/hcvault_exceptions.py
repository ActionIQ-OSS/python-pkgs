class VaultError(Exception):
    def __init__(self, message=""):
        super(VaultError, self).__init__(message)


class InvalidRequest(VaultError):           # 400
    pass


class Unauthorized(VaultError):             # 401
    pass


class Forbidden(VaultError):                # 403
    pass


class InvalidPath(VaultError):              # 404
    pass


class RateLimitExceeded(VaultError):        # 429
    pass


class InternalServerError(VaultError):      # 500
    pass


class VaultNotInitialized(VaultError):      # 501
    pass


class VaultSealed(VaultError):              # 503
    pass


class UnexpectedError(VaultError):          # All other status codes
    pass


class InvalidSecretFormat(VaultError):
    pass


class ContextValidationError(Exception):
    def __init__(self, context_config, message):
        message = "Invalid config for HCVault context: {}\nConfig contents: {}" \
            .format(message, context_config)
        super(ContextValidationError, self).__init__(message)
