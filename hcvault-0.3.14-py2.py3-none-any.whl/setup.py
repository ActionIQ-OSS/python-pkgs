"""A setuptools based setup module.

See:
https://packaging.python.org/en/latest/distributing.html
https://github.com/pypa/sampleproject
"""
from codecs import open
from os import path
from setuptools import setup, find_packages

here = path.abspath(path.dirname(__file__))

setup(
    name='hcvault',  # Required
    version='0.3.14',  # Required
    description='A library with tools for creating a client for HashiCorp Vault',  # Required
    author='ActionIQ, JD Kemsley',  # Optional
    author_email='jdkemsley@actioniq.com',  # Optional
    classifiers=[  # Optional
        'Development Status :: 3 - Alpha',
        'Programming Language :: Python :: 2.7'
        'Programming Language :: Python :: 3'
    ],
    packages=[''],
    # py_modules=['hcvault_exceptions', 'hcvault_client'],
    install_requires=['requests>=2.21.0', 'pyhcl'],  # Optional
    extras_require={
        'parser': ['pyhcl>=0.2.1,<0.3.0']
    },
    # --universal makes the wheel loadable by both py2 and py3
    # The library must be both py2 and py3 compatibile!
    # https://realpython.com/python-wheels/#specifying-a-universal-wheel
    options={"bdist_wheel": {"universal": True}},
    scripts=['hcvault']
)
