from __future__ import print_function

import time
from collections import OrderedDict
from six.moves import input

import hcvault_exceptions
from hcvault_utils import TempSecretFile


# ================================================================================
# NOTE: HCVault PRs are an in-house feature developed to address the problem of
# making live secret changes without peer review.  The feature hasn't seen
# production use yet and was developed before the 1.0 release of Vault.  While it
# may be useful, consume this part of the hcvault lib with a grain of salt.
# ================================================================================


# ================================================================================
# While this module includes logic for a PR system, it relies on a permission system being in place. There are two keys:
#
# 1. The edit path must be create-only, with no updates allowed. Otherwise, the PR system will have problems with race
# conditions, concurrent editing, and approved edits being subsequently edited.
#
# 2. The merge logic requires to 'proposed_by' and 'reviewed_by' to contain two different values. For this to be
# effective, users' write capabilities to these fields must be limited to their own usernames.
# ================================================================================

# ================================================================================
#
# Main functions
#
# ================================================================================


def propose_edit(path, client, proposal_timestamp=None):
    if proposal_timestamp:
        starting_data = read_proposal_path(get_proposal_path(path, proposal_timestamp), client)
    else:
        starting_data = read_live_path(path, client)

    with TempSecretFile(starting_data) as s:
        s.edit()
        edited_data = s.get_json_if_changed()
        if edited_data:
            print("got edited data: {}".format(edited_data))
            proposal_path = write_proposal(path, edited_data, client)
            print("Your proposed edits were written to {}".format(proposal_path))
        else:
            print("No edits made, aborting proposal")


def show_proposal(path, proposal_timestamp, client):
    proposal_path = get_proposal_path(path, proposal_timestamp)
    data = read_proposal_chain(path, proposal_path, client)
    with TempSecretFile(data) as s:
        s.view()


def list_proposals(path, client):
    proposal_paths = get_all_proposal_paths(path, client)
    print("Edit proposals at {} : ".format(path))
    print("\n".join(proposal_paths))


def pull_request(path, proposal_timestamp, client, comments=""):
    proposal_path = get_proposal_path(path, proposal_timestamp)
    # Read proposal chain just to make sure there actually is a proposal here
    read_proposal_chain(path, proposal_path, client)
    pr_path = write_pull_request(proposal_path, comments, client)
    print("Wrote pull-request to {}".format(pr_path))


def review_pull_request(path, proposal_timestamp, client):
    proposal_path = get_proposal_path(path, proposal_timestamp)
    data = read_proposal_chain(path, proposal_path, client, require_pr=True)
    if data["review"] or data["merge_result"]:
        raise ValueError("Can't review a pull request that has already been reviewed or merged.")

    with TempSecretFile(data) as s:
        s.view()

        while True:
            review_result = input("How do you respond to this pull request? accept, reject, review later "
                                  "[review later] :") or "review later"
            if review_result in ["accept", "reject", "review later", "later"]:
                break
            print("Invalid input : {}".format(review_result))

        if review_result in ["review later", "later"]:
            return

        comments = input("Comments to add to this review : ")
        review_path = write_review(proposal_path, review_result, comments, client)
        print("Review written to {}".format(review_path))


def merge_pull_request(path, proposal_timestamp, client):
    proposal_path = get_proposal_path(path, proposal_timestamp)
    data = read_proposal_chain(path, proposal_path, client)
    print("data : {}".format(data))
    if data["merge_result"]:
        raise ValueError("Can't merge a pull request that has already been merged")

    if not data["review"] or not data["review"].get("reviewed_by") or not data["review"].get("review_result"):
        raise ValueError("Incomplete review found at {}. 'reviewed_by' and 'review_result' are required fields."
                         .format(proposal_path))

    if not data["pull_request"] or not data["pull_request"].get("proposed_by"):
        raise ValueError("Incomplete pull_request found at {}. 'proposed_by is a required field."
                         .format(path, proposal_timestamp))

    if data["pull_request"]["proposed_by"] == data["review"]["reviewed_by"]:
        raise ValueError("Can't merge pull request at {}, since it was 'proposed_by' and 'approved_by' the same "
                         "userpass account: {}".format(proposal_path, data["pull_request"]["proposed_by"]))

    if data["review"]["review_result"] != "accept":
        raise ValueError("Can't merge pull request at {}, since the review rejected it".format(proposal_path))
    written_path = write_live_path(path, data["proposed_values"], client)
    write_merge_result(proposal_path, "merged", client)
    print("Merged pull request into live path at {}".format(written_path))


# ================================================================================
#
# Path construction
#
# ================================================================================

DEFAULT_MOUNT_POINT = "/edit"


# For a given path with structure <path> == <secret_root>/<sub_path>, the edit path is:
# <edit_path> == /edit/<secret_root>/<sub_path>
#
# E.G. /secret/mything -> /edit/secret/mything
def get_edit_path(path, mount_point=DEFAULT_MOUNT_POINT):
    path_elements = [_f for _f in path.split("/") if _f]
    if not path_elements:
        raise ValueError("HCVault path must at least include root path for key/value secrets (e.g. '/secret')")
    return "/".join([mount_point.rstrip("/")] + path_elements)


def new_proposal_path(path):
    timestamp = int(time.time())
    return get_proposal_path(path, timestamp)


# /edit/secret/mything/<timestamp>
def get_proposal_path(path, proposal_timestamp):
    if not proposal_timestamp:
        raise ValueError("proposal_timestamp must be non-empty to generate proposal_path")
    return "{}/{}".format(get_edit_path(path), proposal_timestamp)


# /edit/secret/mything/<timestamp>/pr
def get_pull_request_path(proposal_path):
    return "{}/pr".format(proposal_path)


# /edit/secret/mything/<timestamp>/pr/review
def get_review_path(proposal_path):
    return "{}/review".format(get_pull_request_path(proposal_path))


# /edit/secret/mything/<timestamp>/pr/merge
def get_merge_result_path(proposal_path):
    return "{}/merge".format(get_pull_request_path(proposal_path))


# The main functions relying on this to determine what live path should be written to by a given proposal
# too easily lends itself to people mis-inputting, but I'm not sure it's useless yet (jdkemsley 2/2018)

# def get_path_from_propose_path(proposal_path):
#     path_elements = filter(None, proposal_path.split("/"))
#     if len(path_elements) < 3 or path_elements[0] != "edit":
#         raise ValueError("Invalid edit proposal path. Must have form /edit/<secret_root>/<sub_path>/<timestamp>")
#
#     del path_elements[1]
#     del path_elements[len(path_elements) - 1]
#     return "/" + "/".join(path_elements)


# ================================================================================
#
# Read / Write functions
#
# ================================================================================


def write_live_path(path, data, client):
    # TODO jdkemsley : implement history-preserving writes
    client.write(path=path, **data)
    return path


def read_live_path(path, client):
    try:
        # TODO jdkemsley : Write a check to make sure this path is actually part of a key/value backend
        data = client.read(path)["data"]
    # We want a blank slate when the path currently has nothing
    except hcvault_exceptions.InvalidPath:
        data = {}
    return data


def get_all_proposal_paths(path, client):
    edit_path = get_edit_path(path)
    timestamps = client.list(edit_path)["data"]["keys"]
    proposal_paths = []
    for timestamp in timestamps:
        proposal_paths.append(get_proposal_path(path, timestamp))
    return proposal_paths


def read_proposal_path(proposal_path, client):
    return client.read(proposal_path)["data"]


def write_proposal(path, edited_data, client):
    proposal_path = new_proposal_path(path)
    client.write(path=proposal_path, **edited_data)
    return proposal_path


def write_pull_request(proposal_path, comments, client):
    pr_path = get_pull_request_path(proposal_path)
    username = get_username(client)
    timestamp = int(time.time())
    client.write(pr_path, pr_timestamp=timestamp, proposed_by=username, comments=comments)
    return pr_path


def write_review(proposal_path, review_result, comments, client):
    review_path = get_review_path(proposal_path)
    username = get_username(client)
    timestamp = int(time.time())
    client.write(review_path, review_timestamp=timestamp, reviewed_by=username, review_result=review_result,
                 comments=comments)
    return review_path


def write_merge_result(proposal_path, merge_result, client):
    merge_result_path = get_merge_result_path(proposal_path)
    timestamp = int(time.time())
    display_name = get_display_name(client)
    client.write(merge_result_path, merge_timestamp=timestamp, merge_result=merge_result, merged_by=display_name)
    return merge_result_path


# Get all the information for a proposal and its subsequent pull request, review, and merge
def read_proposal_chain(path, proposal_path, client, require_pr=False, require_review=False, require_merge=False):
    live_data = read_live_path(path, client)
    try:
        proposal_data = client.read(proposal_path)["data"]
    except hcvault_exceptions.InvalidPath:
        raise hcvault_exceptions.InvalidPath("No edit proposal found at {}".format(proposal_path))

    try:
        pr_path = get_pull_request_path(proposal_path)
        pr_data = client.read(pr_path)["data"]
    except hcvault_exceptions.InvalidPath:
        if require_pr:
            raise hcvault_exceptions.InvalidPath(" Proposal at {} has no pull request".format(proposal_path))
        pr_data = None

    try:
        review_path = get_review_path(proposal_path)
        review_data = client.read(review_path)["data"]
    except hcvault_exceptions.InvalidPath:
        if require_review:
            raise hcvault_exceptions.InvalidPath(" Proposal at {} has no review".format(proposal_path))
        review_data = None

    try:
        merge_result_path = get_merge_result_path(proposal_path)
        merge_result_data = client.read(merge_result_path)["data"]
    except hcvault_exceptions.InvalidPath:
        if require_merge:
            raise hcvault_exceptions.InvalidPath(" Proposal at {} has no merge result".format(proposal_path))
        merge_result_data = None

    # insertion order in python dicts isn't maintained until 3.6 :(
    all_data = OrderedDict([
        ("secret_path", path),
        ("proposal_path", proposal_path),
        ("live_values", live_data),
        ("proposed_values", proposal_data),
        ("pull_request", pr_data),
        ("review", review_data),
        ("merge_result", merge_result_data)
    ])
    return all_data


def get_username(client):
    try:
        return client.lookup_token()["data"]["meta"]["username"]
    # 'None' for 'meta' or no 'username' key means the client's token does not come from userpass
    except (TypeError, KeyError):
        raise hcvault_exceptions.Unauthorized("You must be authenticated with userpass to user hcvault_pr")


def get_display_name(client):
    # every hcvault token has a display name
    return client.lookup_token()["data"]["display_name"]
