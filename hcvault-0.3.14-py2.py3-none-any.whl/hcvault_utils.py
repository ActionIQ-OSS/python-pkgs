from __future__ import print_function

import json
import os
import pydoc
import shlex
import shutil
import subprocess
import tempfile
from six.moves import input

import hcvault_contexts
import hcvault_exceptions


def show_live_values(path, client=None):
    if not client:
        client = hcvault_contexts.default_client()
    try:
        data = client.read(path)["data"]
    except hcvault_exceptions.InvalidPath:
        data = {}
    with TempSecretFile(data) as s:
        s.view()

# ================================================================================
#
# ContextManager for temp secret files
#
# ================================================================================


class TempSecretFile():
    """
    To be used for viewing and editing local copies of secrets stored in hcvault (which are returned in JSON)

    The viewer is the pydoc pager, which ultimately uses 'less'
    The editor is determined by the $EDITOR env variable but defaults to 'vi'. Only works as intended for in-shell
    editors.

    Once the viewing/editing has finished, any local copies are cleaned up.
    """
    def __init__(self, original_json):

        self._temp_home = tempfile.mkdtemp()
        self._secret_filename = os.path.join(self._temp_home, "hcvault_temp")
        self.original_json = original_json

    def __enter__(self):
        with open(self._secret_filename, "w") as f:
            text = json.dumps(self.original_json, indent=4)
            f.write(text)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        # TODO jdkemsley try shredding like ansible-vault implements
        shutil.rmtree(self._temp_home)

    def edit(self):
        # we validate the temp file as valid JSON, so we edit in a loop to prevent work from just being thrown away
        while True:
            subprocess.call(self.editor_shell_command(self._secret_filename))
            try:
                self.current_json()
                break
            except ValueError as e:
                print(e.message)
                action = input("Your edits do not form valid json. Do you wish to continue editing? [Y/n]")[:1]
                if action and action not in ["y", "Y"]:
                    break

    def view(self):
        with open(self._secret_filename, "r") as f:
            pydoc.pager(f.read())

    def current_json(self):
        with open(self._secret_filename, "r") as f:
            return json.load(f)

    def get_json_if_changed(self):
        current_json = self.current_json()
        if json.dumps(current_json, sort_keys=True) != json.dumps(self.original_json, sort_keys=True):
            return current_json
        return None

    @staticmethod
    def editor_shell_command(filename):
        env_editor = os.environ.get('EDITOR', 'vi')
        editor = shlex.split(env_editor)
        editor.append(filename)
        return editor


# ================================================================================
#
# General utils for plugging into other python tooling (eg. jinja)
#
# ================================================================================


def get_secret(path, *args, **kwargs):
    """
    Get a secret from HCVault at a given path. each secret in hcv is a key:value.
    Provide the key to get the value, otherwise you'll get the kv pair as a python dict.
    You can also pass a list of keys to dive deeper into a dict, or an index value to
    pull from a list. (as *args)

    Accepts a persistent client as an optional arg in case you don't want to
    reinstate a new client every call to get_secret.

    ex)
    given secret at /cubbyhole/spellbook:
    {
        "magic_word": "alohomora",
        "spellcaster": "hgranger"
    }

    get_secret("/cubbyhole/spellbook", key="magic_word")   # output: alohamora
    """
    client = kwargs.get("client")
    if not client:
        client = hcvault_contexts.default_client()
    return client.read_data(path, *args)


def put_secret(path, client=None, **kwargs):
    """
    Put a secret into HCVault at a given path. Each secret in hcv is a key:value.

    Accepts a persistent client as an optional arg in case you don't want to
    resinstate a new client every call to put_secret.

    exs)
    put_secret("/cubbyhole/books/harry_potter", protagonist="hpotter")
    put_secret("/cubbyhole/spells", **{"unlock": "alohomora", "lift": "wingardium leviosa"})
    """
    if not client:
        client = hcvault_contexts.default_client()
    client.write(path, **kwargs)


def get_secret_or_else(path, *args, **kwargs):
    """
    Get secret at path, and if it doesn't exist, return a default

    get_secret("cubbyhole/path/to/secret", "key", default="EMPTY")
    """
    try:
        secret = get_secret(path, *args, **kwargs)
    except (hcvault_exceptions.InvalidPath, KeyError):
        secret = kwargs.get("default")
    return secret
